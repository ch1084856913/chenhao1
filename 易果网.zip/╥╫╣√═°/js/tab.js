
	$("#tab").find("li").click(function(){
				$(this).addClass("active").siblings().removeClass("active");
				
				$("p").removeClass("active").eq($(this).index()).addClass("active");
			})
			









