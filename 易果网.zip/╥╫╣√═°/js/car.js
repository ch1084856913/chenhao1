		
		class Car{
			constructor(options){
//				1.解析参数
				this.tbody = options.tbody;
				this.url = options.url;
				
//				2.请求数据
				this.load();
				
//				5.绑定事件
				this.addEvent();
			}
			load(){
//				console.log(1)
				var that = this;
				ajax({
					url:this.url,
					success:function(res){
						that.res = JSON.parse(res);
//						3.获取cookie
						that.getCookie();
					}
				})
			}
			getCookie(){
				console.log(1)
//				获取cookie
				this.goods = JSON.parse(getCookie("goods"));
				console.log(this.goods)
//				4.渲染页面
				this.display()
			}
			display(){
				console.log(1)
				var str = "";
//				比对cookie和总数据
				for(var i=0;i<this.res.length;i++){
					for(var j=0;j<this.goods.length;j++){
						if(this.res[i].goodsId == this.goods[j].id){
							str += `<tr>
										<td><input type="checkbox" name="" id="" value="" /></td>
										<td><img src="${this.res[i].src}"/></td>
										<td>${this.res[i].name}</td>
										<td>${this.res[i].price}</td>
										<td><input type="number" value="${this.goods[j].num}"></td>
										<td><em data-index="${this.res[i].goodsId}">删除</em></td>
									</tr>`
						}
					}
				}
				this.tbody.innerHTML = str;
			}
			addEvent(){
				console.log(1)
				var that = this;
				this.tbody.addEventListener("click",function(eve){
					if(eve.target.nodeName == "EM"){
//						找到点击商品的货号
						that.id = eve.target.getAttribute("data-index");
//						删除DOM元素
						eve.target.parentNode.parentNode.remove();
//						6.遍历cookie,找到符合条件的数据,做删除
						that.changeCookie(function(index){
//							8.删除并再次设置回去
							that.goods.splice(index,1);
						})
					}
				})
				this.tbody.addEventListener("input",function(eve){
					if(eve.target.type == "number"){
//						10.先获取修改之后的数量,再获取当前商品的id
						that.value = eve.target.value;
						that.id = eve.target.parentNode.nextElementSibling.children[0].getAttribute("data-index");
//						11.遍历cookie,找到符合条件的数据,做修改
						that.changeCookie(function(index){
							that.goods[index].num = that.value;
						});
					}
				})
			}
			changeCookie(callback){
//				7.找到cookie中符合条件的数据
				for(var i=0;i<this.goods.length;i++){
					if(this.goods[i].id == this.id){
						break;
					}
				}
				
				callback(i);
				
//				9.再设置回去
//				12.再设置回去
				setCookie("goods",JSON.stringify(this.goods))
			}
		}
		
		new Car({
			tbody:document.getElementById("tbody"),
			url:"./data/goods.json"
		})
		





















